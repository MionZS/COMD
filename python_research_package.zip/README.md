# Python + research package

## Contents
- `generate_figures.py`: final script that generates all figures used in the article.
- `figures/`: generated PNG figures.
- `research_notes.md`: compact theoretical basis for the discussion.
- `assignment.pdf`: original assignment statement.
- `original_spyder_script.py`: original Spyder-based file you uploaded.
- `original_marimo_script.py`: original marimo-based file you uploaded.

## Run
Use a Python environment with:
- numpy
- matplotlib
- scipy

Then run:

```bash
python generate_figures.py
```

The current script saves figures using paths that match the original article workflow.
If you want, these output paths can be adjusted later.
