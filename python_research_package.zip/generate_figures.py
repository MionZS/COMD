import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.signal import welch

Tb = 1.0
fs = 10.0
Ts = 1/fs
Nb = 10**5
Nview_bits = 10

rng = np.random.default_rng(42)
bits = rng.integers(0,2,Nb)

def pulse_rect_half(Tb, fs):
    n = max(1, int(round((Tb/2)*fs)))
    return np.ones(n)

def pulse_rect_full(Tb, fs):
    n = max(1, int(round(Tb*fs)))
    return np.ones(n)

def pulse_sine(Tb, fs):
    n = max(1, int(round(Tb*fs)))
    t = np.arange(n)/fs
    return np.sin(np.pi*t/Tb)

pulses = {
    'rect_half': (pulse_rect_half(Tb, fs), 'p(t)=Pi(2t/Tb)'),
    'rect_full': (pulse_rect_full(Tb, fs), 'p(t)=Pi(t/Tb)'),
    'sine': (pulse_sine(Tb, fs), 'p(t)=sin(pi t/Tb)'),
}


def map_polar(bits):
    return 2*bits - 1

def map_onoff(bits):
    return bits.astype(float)

def map_bipolar(bits):
    out = np.zeros_like(bits, dtype=float)
    sign = 1.0
    for i,b in enumerate(bits):
        if b == 1:
            out[i] = sign
            sign *= -1
    return out

linecodes = {
    'polar': (map_polar(bits), 'Polar'),
    'onoff': (map_onoff(bits), 'On-Off'),
    'bipolar': (map_bipolar(bits), 'Bipolar (AMI)'),
}


def synthesize(symbols, pulse, fs, Tb):
    Ns = int(round(Tb*fs))
    x = np.zeros(len(symbols)*Ns)
    x[::Ns] = symbols
    y = np.convolve(x, pulse, mode='full')
    t = np.arange(len(y))/fs
    return x, y, t

# Generate signals and PSDs
cache = {}
for pkey, (p, plabel) in pulses.items():
    for ckey, (a, clabel) in linecodes.items():
        x, y, t = synthesize(a, p, fs, Tb)
        ff, S = welch(y, fs=fs, nperseg=2048, return_onesided=False, detrend=False)
        ff = np.fft.fftshift(ff)
        S = np.fft.fftshift(S)
        cache[(pkey, ckey)] = dict(x=x, y=y, t=t, ff=ff, S=S, plabel=plabel, clabel=clabel)

# time-domain figures per pulse
for pkey, (_, plabel) in pulses.items():
    fig, axes = plt.subplots(3,1, figsize=(7.2,6.6), sharex=True)
    for ax, ckey in zip(axes, ['polar','onoff','bipolar']):
        d = cache[(pkey, ckey)]
        mask = d['t'] < Nview_bits*Tb
        ax.plot(d['t'][mask], d['y'][mask], linewidth=1.5)
        ax.set_ylabel('Amp.')
        ax.set_title(d['clabel'])
        ax.grid(True, alpha=0.3)
    axes[-1].set_xlabel('Time (s)')
    fig.suptitle('Time-domain line codes', y=0.995)
    fig.tight_layout()
    fig.savefig(f'/mnt/data/article_work/time_{pkey}.png', dpi=220, bbox_inches='tight')
    plt.close(fig)

# PSD figures per pulse
for pkey, (_, plabel) in pulses.items():
    fig, axes = plt.subplots(3,1, figsize=(7.2,6.8), sharex=True)
    for ax, ckey in zip(axes, ['polar','onoff','bipolar']):
        d = cache[(pkey, ckey)]
        ax.plot(d['ff'], 10*np.log10(d['S'] + 1e-16), linewidth=1.2)
        ax.set_ylabel('PSD (dB/Hz)')
        ax.set_title(d['clabel'])
        ax.grid(True, alpha=0.3)
        ax.set_xlim(-5,5)
        ax.set_ylim(-70,10)
    axes[-1].set_xlabel('Frequency (Hz)')
    fig.suptitle('Welch PSD estimates', y=0.995)
    fig.tight_layout()
    fig.savefig(f'/mnt/data/article_work/psd_{pkey}.png', dpi=220, bbox_inches='tight')
    plt.close(fig)

# pulse shapes figure
fig, ax = plt.subplots(figsize=(7.2,3.0))
for pkey, (p, plabel) in pulses.items():
    tp = np.arange(len(p))/fs
    ax.plot(tp, p, linewidth=2, label=plabel)
ax.set_xlabel('Time (s)')
ax.set_ylabel('Amplitude')
ax.grid(True, alpha=0.3)
ax.legend()
fig.tight_layout()
fig.savefig('/mnt/data/article_work/pulses.png', dpi=220, bbox_inches='tight')
plt.close(fig)
