#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar 26 13:35:16 2026

@author: andrei
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import welch

#%% Parâmetros de simulação
Tb = 1          # intervalo de pulso (bit) em segundos
fs = 10/Tb      # taxa de amostragem em Hz (amostras/segundo)
T = 1/fs        # intervalo de amostragem (segundos)
N = int(Tb/T)   # Número de amostras do intervalo de amostragem
Nb = 10**5         # Número de bits transmitidos

#%% Geração do código de linha
# Pulso de transmissão NRZ
p = np.ones(N)

# Sinalização Polar
ak = np.random.choice([-1,1],Nb)
x = np.zeros(N*Nb)
x[::N] = ak
y = np.convolve(x,p)

fig, ax = plt.subplots(2,1,figsize=(9,4))
ax[0].stem(x)
ax[0].set_ylabel(r'$x[n]$')
ax[0].set_xlabel(r'$n$ (amostras)')
ax[0].set_xlim(0,200)
ax[0].grid()
t = np.linspace(0,len(y)*T,len(y))
ax[1].plot(t,y)
ax[1].set_ylabel(r'$y(t)$')
ax[1].set_xlabel(r'$t$ (segundos)')
ax[1].set_xlim(0,20*Tb)
ax[1].grid()
plt.tight_layout()
plt.show()

#%% PSD
def psd_polar_nrz(f,Tb):
    Sy_f = Tb * np.sinc(f*Tb)**2
    return Sy_f

    
ff, Sy_f = welch(y,fs,nperseg=1024,return_onesided=False,detrend=False)
    
ff = np.fft.fftshift(ff)    
Sy_f = np.fft.fftshift(Sy_f)    
  
plt.figure()
f_th = np.linspace(-fs/2,fs/2,500)
plt.plot(f_th, 10*np.log10(psd_polar_nrz(f_th,Tb)),'k-')
plt.plot(ff, 10*np.log10(Sy_f),'r--')
plt.ylim(-60,1)
plt.grid()
plt.show()
    
