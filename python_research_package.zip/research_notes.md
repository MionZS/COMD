# Research notes for Trabalho Computacional 1

## Objective
Study how line coding and pulse shaping affect the transmitted waveform in time and frequency.

## Required cases
Three binary line codes:
- Polar
- On-off
- Bipolar AMI

Three transmission pulses:
- Rectangular pulse with width `Tb/2` (`Pi(2t/Tb)`)
- Rectangular pulse with width `Tb` (`Pi(t/Tb)`)
- Sinusoidal pulse over one bit interval (`sin(pi t/Tb)`)

## Expected theoretical trends
### 1. DC component
- **On-off** has nonzero mean for equiprobable bits, so it should show the strongest content near `f = 0`.
- **Polar** is approximately zero-mean, so its DC component should be much smaller.
- **Bipolar AMI** alternates the sign of successive ones, further suppressing low-frequency energy.

### 2. Bandwidth and first null
- A rectangular pulse with duration close to `Tb` tends to produce a first spectral null near `1/Tb`.
- Making the pulse shorter in time broadens the spectrum, so the `Tb/2` pulse tends to push the first null outward, near `2/Tb`.

### 3. Out-of-band behavior
- Abrupt rectangular edges create stronger sidelobes and more spectral leakage outside the essential band.
- A smoother sinusoidal pulse should reduce abrupt transitions and improve out-of-band behavior.

## Numerical method used
The figures are generated from a random sequence of `10^5` equiprobable bits, sampled with:
- `Tb = 1 s`
- `fs = 10 Hz`
- `Ts = 0.1 s`

PSD estimates are obtained with Welch's method.

## Main references
1. John G. Proakis and Masoud Salehi, *Digital Communications*, 5th ed.
2. Bernard Sklar, *Digital Communications: Fundamentals and Applications*, 2nd ed.
3. P. D. Welch, "The use of fast Fourier transform for the estimation of power spectra", IEEE Trans. Audio Electroacoustics, 1967.
