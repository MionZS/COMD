# Article package

This package contains the IEEE article split into separate files by section.

## Structure
- `main.tex`: master file that compiles the article.
- `sections/`: content split into independent `.tex` files.
- `figures/`: figures already generated and referenced by the article.
- `IEEEtran.cls`: IEEE class file required by the template.

## Build
Run:

```bash
pdflatex main.tex
pdflatex main.tex
```

If your editor supports LaTeX build recipes, just open `main.tex`.
