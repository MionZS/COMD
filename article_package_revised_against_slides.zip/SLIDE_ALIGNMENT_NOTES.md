# Alignment notes against professor slides

This package was revised against the lecture slides on line codes and report writing.

Main adjustments made:
- strengthened the Introduction with context, literature references, objective, and bullet-point contributions;
- kept methodology/results/conclusion closer to the structure recommended in class;
- removed the placeholder "pending items" section from the final article;
- migrated references to a `.bib` database in IEEE style;
- preserved the assignment parameters from the PDF (`N_b = 10^5`, `T_b = 1 s`, `f_s = 10 Hz`), even though one writing slide shows other values as a generic example.

Important note:
- The professor's analytical slides derive several PSD expressions for the **RZ rectangular pulse of duration `T_b/2`**. In this assignment, however, the article intentionally compares **three pulse shapes**, so the discussion keeps that broader scope.
